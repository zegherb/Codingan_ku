#include <iostream>
#include <string>

using namespace std;
// Permulaan Hello World dan membuat nama, nim, dan kelompok
/*int main()
{

cout << "La Ode Muhammad Aldyansyah Ombi" << endl;
cout << "F1G124036" << endl;
cout<< "Ilmu Komputer" << endl;
cout << "MIPA" << endl;

return 0;


}


int main ()
{
     cout << "La Ode Muhammad Aldyansyah Ombi" << endl;
     cout << "F1G124036" << endl;
     cout << "Genap A" << endl;
     return 0;
}*/
/*
// Tipe data dan variabel
int main ()
{
    int a = 2;
    int b = 3;
    int c = a;
    a = b;
    b = c;
    cout << "a : " << a << endl;
    cout << "b : " << b << endl;
    
    return 0;
}*/
/*
#include <iostream>
using namespace std;
float c = 5;
int main()
{int a = 3, b = 2, savea, saveb; 
savea = a;
 saveb = b;
 a = c;
 b = savea;
 c = saveb;
 cout << "a = " << a << endl;
 cout << "b = " << b << endl;
  cout << "c = " << c << endl;
  }*/


// using namespace std;

//  int main()
//  {
  

// float alas, tinggi, luas;
// cout << "Masukkan alas :";
// cin >> alas;
// cout << "Masukkan tinggi :";
// cin >> tinggi;

// luas = 0.5 * alas * tinggi;
//  cout << "Hasilnya adalah : " << luas;
//     return 0;
// }
/*
#include <iostream>
using namespace std;

float fahrenheit, celcius, kelvin, reamur;

int main()
{
    
    cout << "=====PROGRAM KONVERSI SUHU=====\n" << endl;
    cout << "Masukkan Suhu Fahrenheit : ";
    cin >> fahrenheit;

    celcius = 0.55555555556 * (fahrenheit-32);
    kelvin = (fahrenheit-32) * 0.55555555556 + 273;
    reamur = (fahrenheit-32) * 0.44444444444;
    cout << endl;
    cout << "Hasil Konversi dari Suhu Fahrenheit ke Celcius : " << celcius <<endl;
    cout << "Hasil Konversi dari Suhu Fahrenheit ke Kelvin  : " << kelvin <<endl;
    cout << "Hasil Konversi dari Suhu Fahrenheit ke Reamur  : " << reamur <<endl;

    return 0;
}*/
/*
int main()
{
    int a = 5; 

    cout << "Post Increment" << endl;
    cout << a++ << endl;
    cout << a;



    

    return 0;
}*/

int main()
{
    int a;

    cout << "Masukkan Angka : ";
    cin >> a;

    string hasil = (a == 1)? "Angka 1": "Bukan Angka 1 ";
    cout << hasil;
    return 0;
}




    
 
 
 





 

