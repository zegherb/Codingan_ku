#include <iostream>
using namespace std;

// int main()
// {
//     int a = -1;
//     int b = -2;
//     cout << "\n Ini While" << endl;
//     while (a > -100)
//     {
//         cout << a << endl;
//         a-= 2;
//     }
//     cout << "\n Ini Do While" << endl;
//     do{
//      cout << b << endl;
//      b-= 2;