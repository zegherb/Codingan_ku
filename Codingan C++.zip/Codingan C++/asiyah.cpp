#include <iostream>
using namespace std;
/*
int main ()
{
float hasil;
cout << "=========PEMBAGIAN 1-5=========" <<endl;
for (float i = 1; i <= 5; i++){
    for (float j = 1; j <= 5; j++)
    {
        hasil = i / j;
        cout << i << " / " << j << " = " << hasil << endl;
    }
    cout << endl;
}
return 0;
}*/
/*
#include <iostream>
using namespace std;

int main()
{
    int i;
    for (i = 1; i <= 7; i++)
    {
        cout << i << endl;
    }
    
}*/
/*
#include <iostream>
using namespace std;

int main()
{
    int i = 0;
    while (i < 7)
    {
        i+=1;
        cout << i << endl;
    }
    
    return 0;
}*/

#include <iostream>
using namespace std;

int main()
{
    int i = 0;
    do
    {
        i+=1;
        cout << i << endl;
    } while (i < 7);
    
    return 0;
}





