// #include <iostream>
// using namespace std;

// int main() {
//     for (int i = 1; i <= 5; i++) {
//         for (int j = 1; j <= i; j++) {
//             cout << i << "*" << j << "=" << i*j << endl;
//         }
//         cout << endl;
//     }
//      return 0;
// }

// #include <iostream>
// using namespace std;

// int main() {
//     for (int i = 1; i <= 5; i++) {
//         cout << "Angka: " << i << endl;
//     }
//     return 0;
// }

#include <iostream>
using namespace std;

int main() {
    int i = 1;
    while (i <= 5) {
        cout << "Angka: " << i << endl;
        i++;
    }
    return 0;
}
