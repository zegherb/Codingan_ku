#include <iostream>
using namespace std;
int main() {
    // Program dengan 1 for
    cout << "Menggunakan 1 for:" << endl;
    for (int i = 1; i <= 20; i++) {
        cout << i << " ";
    }
    cout << endl;
    return 0;
}